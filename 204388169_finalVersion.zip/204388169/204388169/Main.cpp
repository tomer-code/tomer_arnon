#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <omp.h>
#include <math.h>
#include "cuda_runtime.h"
#include "device_launch_parameters.h"

#define MASSIVE 10000
#define ROOT 0
#define TAG  0

extern cudaError_t  addWithCuda(int* A,int* resultsCuda, int size);

double f(int i);

int checkWithOmp(int* arr, int* newArr, int size);


int main(int argc, char* argv[])
{
	int* A,  *resultsCuda, *resultsOpenMP;
	//int* newArray;
	double t0, t1;
	int size = 0, i, countomp = 0;
	int sumProc1 = 0, totalSumProc = 0, myid, numprocs;
	FILE* file;
	cudaError_t cudaStatus;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &myid);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
	MPI_Status status;

	t0 = MPI_Wtime();

	if (myid == ROOT) {

		file = fopen("C:\\Users\\cudauser\\Downloads\\204388169\\204388169\\Text.txt", "r");
		if (!file) {
			printf("file is fail opening, please try again!");
			return 1;
		}

		fscanf(file, "%d", &size);
		A = (int*)malloc(size * sizeof(int));
		//printf("the array is: \n");
		for (i = 0; i < size; i++) {
			fscanf(file, "%d", &A[i]);
			//printf("%d\n", A[i]);
		}

		resultsCuda = (int*)malloc((size / 4) * sizeof(int));

		MPI_Send(A + (size / 2), size / 2, MPI_INT,
			1, TAG, MPI_COMM_WORLD);

		 cudaStatus = addWithCuda(A + (size/4), resultsCuda, size/4);
		if (cudaStatus != cudaSuccess) {
			fprintf(stderr, "addWithCuda failed!");
			return 1;
		}

		resultsOpenMP = (int*)malloc((size / 4) * sizeof(int));

		countomp += checkWithOmp((A + size/4), resultsOpenMP,size / 4);

		MPI_Recv(&sumProc1, 1, MPI_INT, 1,
			TAG, MPI_COMM_WORLD, &status);


		int sum = sizeof(resultsCuda) / sizeof(resultsCuda[0]);
		totalSumProc = sumProc1 + countomp + sum;


		/*newArray = (int*)malloc(sizeC * sizeof(int));
		for (i = 0; i < sizeof(newArray)/newArray[0]; i++) {
			newArray[i] = resultsCuda[i];
		}

		newArray = (int*)realloc(newArray, sizeB*sizeof(int));

		

		int count = 0;
		for (i = 0; i < sizeof(newArray) / newArray[0]; i++) {
			count++;
		}*/

		t1 = MPI_Wtime();
		double totalTime = t1 - t0;
		printf("the count of positive results is:\n %d", &totalSumProc);
		printf("time running:\n %lf", totalTime);

	}

	else
	{
		int* numbers;
		int totalCountProc1 = 0, sizeCuda = 0;
		numbers = (int*)malloc(size / 2 * sizeof(int));

		MPI_Recv(numbers, size / 2, MPI_INT, ROOT,
			TAG, MPI_COMM_WORLD, &status);

		cudaStatus = addWithCuda(numbers + (size/4), resultsCuda, size/4);
		if (cudaStatus != cudaSuccess) {
			fprintf(stderr, "addWithCuda failed!");
			return 1;
		}

		sizeCuda = sizeof(resultsCuda) / sizeof(resultsCuda[0]);

		countomp += checkWithOmp((numbers + size / 4), resultsOpenMP, size / 4);

		totalCountProc1 = countomp + sizeCuda;

		MPI_Send(&totalCountProc1, 1, MPI_INT, ROOT, TAG, MPI_COMM_WORLD);

	}
	cudaStatus = cudaDeviceReset();
	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "cudaDeviceReset failed!");
		return 1;
	}

	free(A);
	free(resultsCuda);
	free(resultsOpenMP);
	MPI_Finalize();
	
	

}



double f(int i) {
	int j;
	double value;
	double result = 0;

	for (j = 1; j < MASSIVE; j++) {
		value = (i + 1)*(j % 10);
		result += cos(value);
	}
	return cos(result);
}

int checkWithOmp(int* arrFromFile, int* newArr, int size)
{
	int i, count;
#pragma omp parallel
	{
#pragma omp for
		for (i = 0; i < size; i++) {
			if (f(arrFromFile[i]) > 0) {
				newArr[arrFromFile[i]++];

			}
		}
		count = sizeof(newArr) / newArr[0];
	}
	return count;
}

